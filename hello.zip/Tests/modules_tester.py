'''
    This module is meant to implement different functions to test the different 
    modules and functionalities that the project contains. It would bring more clarity to
    users and to reproduce the effects of specefic functionality if one
    is interested in a specific part of the project.
'''

