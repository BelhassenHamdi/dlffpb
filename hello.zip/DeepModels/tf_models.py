'''
    This file contains several tensorflow models ready to be used
'''
import tensorflow as tf
from tensorflow.contrib.compiler import xla

class TFmodel():
    def __init__():
        