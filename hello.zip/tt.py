x = 5
if x >= 11:
    y = 3
else:
    if x < 6:
        y = 4
    else:
        y = 2
    z = x * y + 1
    print(z,z)